<template>
  <div id="app">
    <TaskBoard />
  </div>
</template>

<script>
import TaskBoard from "./components/TaskBoard.vue";

export default {
  components: {
    TaskBoard,
  },
};
</script>

<style>
body {
  font-family: Arial, sans-serif;
  background-color: #f4f4f4;
  margin: 0;
  padding: 0;
}
</style>
