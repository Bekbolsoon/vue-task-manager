<template>
  <div class="task-form">
    <input v-model="taskText" type="text" placeholder="Введите задачу" @keyup.enter="submitTask" />
    <button @click="submitTask">Сохранить</button>
    <button @click="cancelAddingTask">Отмена</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      taskText: "",
    };
  },
  methods: {
    submitTask() {
      if (this.taskText.trim()) {
        this.$emit("add-task", this.taskText.trim());
        this.taskText = "";
      }
    },
    cancelAddingTask() {
      this.$emit("close");
    },
  },
};
</script>

<style scoped>
.task-form {
  display: flex;
  flex-direction: column;
  gap: 5px;
}
input {
  padding: 5px;
  width: 100%;
}
button {
  padding: 5px;
  cursor: pointer;
}
</style>
