<template>
  <div class="task-board">
    <div v-for="section in sections" :key="section.id" class="task-column">
      <h2>{{ section.title }}</h2>
      <draggable
        v-model="section.tasks"
        :group="'tasks'"
        @start="dragStart"
        @end="dragEnd"
        class="task-list">
        <div v-for="task in section.tasks" :key="task.id" class="task-item">
          <p>{{ task.text }}</p>
          <button @click="showContextMenu(task, section.id)">...</button>
        </div>
      </draggable>
      <TaskForm v-if="section.showForm" @add-task="addTask(section.id, $event)" @close="cancelAddingTask(section.id)" />
      <button v-else @click="showTaskForm(section.id)">Добавить</button>
    </div>

    <!-- Модальное окно для удаления задачи -->
    <div v-if="isModalVisible" class="modal">
      <div class="modal-content">
        <p>Вы уверены, что хотите удалить задачу?</p>
        <button @click="deleteTask">Удалить</button>
        <button @click="closeModal">Отмена</button>
      </div>
    </div>
  </div>
</template>

<script>
import TaskForm from "./TaskForm.vue";
import draggable from "vuedraggable";

export default {
  components: { TaskForm, draggable },
  data() {
    return {
      sections: [
        { id: 1, title: "На согласовании", tasks: [], showForm: false },
        { id: 2, title: "Новые", tasks: [], showForm: false },
        { id: 3, title: "В процессе", tasks: [], showForm: false },
        { id: 4, title: "Готово", tasks: [], showForm: false },
        { id: 5, title: "Доработать", tasks: [], showForm: false },
      ],
      taskToDelete: null,
      isModalVisible: false,
      taskSectionId: null,
    };
  },
  methods: {
    showContextMenu(task, sectionId) {
      this.taskToDelete = task;
      this.taskSectionId = sectionId;
      this.isModalVisible = true;
    },
    closeModal() {
      this.isModalVisible = false;
      this.taskToDelete = null;
      this.taskSectionId = null;
    },
    deleteTask() {
      const section = this.sections.find((s) => s.id === this.taskSectionId);
      const taskIndex = section.tasks.indexOf(this.taskToDelete);
      if (taskIndex > -1) {
        section.tasks.splice(taskIndex, 1);
        alert(`Задача удалена`);
      }
      this.closeModal();
    },
    showTaskForm(sectionId) {
      this.sections.forEach((s) => (s.showForm = s.id === sectionId));
    },
    cancelAddingTask(sectionId) {
      const section = this.sections.find((s) => s.id === sectionId);
      section.showForm = false;
    },
    addTask(sectionId, text) {
      const section = this.sections.find((s) => s.id === sectionId);
      section.tasks.push({ id: Date.now(), text });
      section.showForm = false;
      alert(`Задача создана в "${section.title}"`);
    },
    dragStart() {
      console.log("Перетаскивание началось");
    },
    dragEnd() {
      console.log("Перетаскивание завершено");
    },
  },
};
</script>

<style scoped>
.task-board {
  display: flex;
  gap: 16px;
  padding: 20px;
}

.task-column {
  width: 20%;
  background: white;
  padding: 10px;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.task-list {
  min-height: 100px;
  max-height: 300px;
  overflow-y: auto;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.task-item {
  background: #e3e3e3;
  padding: 5px;
  margin-bottom: 5px;
  border-radius: 4px;
}

button {
  margin-top: 10px;
  width: 100%;
  padding: 5px;
}

/* Стиль для модального окна */
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  text-align: center;
}

.modal-content button {
  margin: 10px;
}
</style>
